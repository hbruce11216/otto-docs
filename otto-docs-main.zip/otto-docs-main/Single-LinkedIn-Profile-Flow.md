# Single LinkedIn Profile Flow

![Single LinkedIn Profile Flow](/images/single-profile-flow.png "Single LinkedIn Profile Flow: Sequence Diagram")